import Footer from "./Pages/Footer";
import Why from "./Pages/Why";
import Glasses from "./Pages/Glasses";
import Cards from "./Pages/Cards";
import ImageSlider from "./Pages/ImageSlider";
const Home = ()=>{
    return(
     <>
<ImageSlider/>
<Cards/>
<Glasses/>
<Why/>
<Footer/>
     </>   

    )
}
export default Home;