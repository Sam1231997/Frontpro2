import { useEffect, useState } from "react";

export default function Notice() {
  const [notices, setNotices] = useState([]);

  useEffect(() => {
    const storedNotices = JSON.parse(localStorage.getItem("notices")) || [];
    setNotices(storedNotices);
  }, []);

  return (
    <div className="relative min-h-screen flex flex-col items-center px-4 py-10 overflow-hidden">
      {/* Faded full-page background */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-15"
        style={{
          backgroundImage: "url('/images/faded.jpg')", // 🔹 change to your background image
        }}
      ></div>

      {/* Content (kept above background) */}
      <div className="relative z-10 flex flex-col items-center">
        <h1 className="text-3xl font-bold mb-6 text-blue-600 text-center">
          Welcome to Our Hospital
        </h1>

        {/* Notices section */}
        <div className="bg-white shadow-lg rounded-2xl p-6 w-full max-w-2xl">
          <h2 className="text-xl font-semibold mb-4">Latest Announcements</h2>
          {notices.length === 0 ? (
            <p className="text-gray-500">No announcements available.</p>
          ) : (
            <ul className="space-y-3">
              {notices.map((notice) => (
                <li
                  key={notice.id}
                  className="border p-3 rounded-lg bg-gray-50 shadow-sm"
                >
                  <p className="text-gray-800">{notice.text}</p>
                  <span className="text-xs text-gray-500">{notice.date}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
