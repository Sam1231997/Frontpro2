import  { useState } from 'react';
import { Link } from 'react-router-dom';
// import { Menu } from '@headlessui/react';
import { MenuIcon, XIcon } from '@heroicons/react/outline';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  const [isDropdownOpen, setIsDropdownOpen] = useState(false); // for Accounts dropdown


  return (
    <header className="bg-white shadow-md  sticky top-0 z-50 ">
      <div className="mx-auto px-4 sm:px-8 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <div className="text-2xl font-bold  text-blue-600">
            <img src="/images/logo.jpg" className='h-24'/>
          </div>

          {/* Navigation Links for Desktop */}
          <nav className="hidden md:flex text-l font-bold space-x-8 align-baseline">
            <Link to="/" className="text-gray-600  hover:text-black hover:bg-purple-300 px-4">Home</Link>
           
            <Link to="/about" className="text-gray-600 hover:text-black hover:bg-purple-300 px-4">About Us</Link>
            <Link to="services" className="text-gray-600    hover:text-black hover:bg-purple-300 px-4">Services</Link>
            <Link to="/register" className="text-gray-600 hover:text-black hover:bg-purple-300 px-4">Register</Link>
             <Link to="/notice" className="text-gray-600 hover:text-black hover:bg-purple-300 px-4">Blog</Link>
                {/* Dropdown Menu for Accounts */}
            <div className="relative">
              <button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="text-gray-600 hover:text-black hover:bg-purple-300 px-4 focus:outline-none"
              >
                Login ▾
              </button>

              {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-40 bg-white shadow-lg rounded-md py-2 z-50">
                  <Link to="/patient" className="block px-4 py-2 text-gray-600 hover:bg-purple-100">Patient</Link>
                  <Link to="/admin" className="block px-4 py-2 text-gray-600 hover:bg-purple-100">Doctor</Link>
                 
                </div>
              )}
            </div>
            
           

          
          </nav>

          {/* Hamburger Menu for Mobile */}
          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-600 hover:text-blue-600 focus:outline-none">
              {isOpen ? <XIcon className="h-6 w-6" /> : <MenuIcon className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden">
            <nav className="flex flex-col space-y-2 py-4 font-bold">
              <Link to="/" className="text-gray-600 hover:text-blue-600">Home</Link>
              
              <Link to="/about" className="text-gray-600 hover:text-blue-600">About us</Link>
              <Link to="/services" className="text-gray-600 hover:text-blue-600">Services</Link>
              <Link to="/notice" className="text-gray-600 hover:text-blue-600">Blog</Link>
             <Link to="/register" className="text-gray-600 hover:text-blue-600">Register</Link>
              {/* Dropdown in Mobile */}
              <div className="flex flex-col">
                <button
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="text-gray-600 hover:text-blue-600 text-left"
                >
                  Login ▾
                </button>
                {isDropdownOpen && (
                  <div className="ml-4 flex flex-col space-y-1">
                    <Link to="/patient" className="text-gray-600 hover:text-blue-600">Patient</Link>
                    <Link to="/admin" className="text-gray-600 hover:text-blue-600">Doctor</Link>

                  </div>
                )}
              </div>
              
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
