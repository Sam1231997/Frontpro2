import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Home from './Home'
import Header from './Pages/Header'

import ProtectedRoute from "./components/ProtectedRoute";
import DashboardLayout from "./Pages/Patient/DashboardLayout";
import PatientBills from "./Pages/Patient/PatientBills";
import Profile from "./Pages/Patient/Profile";
import Appointment from "./Pages/Patient/Appointment";
import AdminReport from "./Pages/Admin/AdminReport";


import About from './Pages/About'
import Services from './Pages/Services';


import ScrollToTop from './Pages/Scroll';

import TestAd from './Pages/TestAd';


import ProtectedAdminRoute from "./components/ProtectedAdminRoute";
import AdminDashboardLayout from "./Pages/Admin/AdminDashboardLayout";
import AdminBills from "./Pages/Admin/AdminBills";
import AdminBillsList from "./Pages/Admin/AdminBillsList";

import PatientLogin from "./Pages/PatientLogin";
import AdminLogin from "./Pages/AdminLogin";
import PatientSignup from "./Pages/PatientSignup";
import BookedAppointments from "./Pages/Patient/BookedAppointments";
import AdminPatients from "./Pages/Admin/AdminPatients";
import AdminAppointments from "./Pages/Admin/AdminAppointments";
import AdminNotice from "./Pages/Admin/AdminNotice";
import Notice from "./Pages/Notice";



function AppRoutes() {
  return (
    <BrowserRouter>
        <ScrollToTop />
    <Header/>
      <Routes>
    
        {/* Public routes */}
        <Route path="/" element={<Home />} />
          <Route path="/about" element={<About/>} />
          <Route path="/services" element={<Services/>}/>
          <Route path="/patient" element={<PatientLogin/>}/>
           <Route path="/admin" element={<AdminLogin/>}/>
          <Route path="/test" element={<TestAd/>}/>
          <Route path="/register" element={<PatientSignup/>}/>
          <Route path="/notice" element={<Notice/>}/>
         

        {/* Protected patient area */}
        <Route
          path="/patient/dashboard"
          element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Navigate to="profile" />} />
          <Route path="profile" element={<Profile/>} />
          <Route path="appointments" element={<Appointment />} />
          <Route path="bookedappointments" element={<BookedAppointments />} />
          <Route path="mybills" element={<PatientBills />} />
        </Route>

        {/* Protected admin area */}
        <Route
          path="/admin/dashboard"
          element={
            <ProtectedAdminRoute>
              <AdminDashboardLayout />
            </ProtectedAdminRoute>
          }
        >
          <Route index element={<Navigate to="records" />} />
          <Route path="records" element={<AdminPatients />} />
          <Route path="adminappointments" element={<AdminAppointments />} />
          <Route path="report" element={<AdminReport />} />
          <Route path="bills" element={<AdminBills />} />
          <Route path="billslist" element={<AdminBillsList />} />
          <Route path="notice" element={<AdminNotice/>} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default AppRoutes;
